#include "./SocketPack.h"

Socket_Pack::Socket_Pack(char* massage)
{
    memset(head,'\0',_HEAD_SIZE);
    memset(body,'\0',_BODY_SIZE);
    memset(end,'\0',_END_SIZE);
    this->code=-1;
    strcpy(body,massage);
}

Socket_Pack::Socket_Pack(char* head,char* body,char* end)
{
    memset(head,'\0',_HEAD_SIZE);
    memset(body,'\0',_BODY_SIZE);
    memset(end,'\0',_END_SIZE);
    this->code=-2;
    strcpy(this->head,head);
    strcpy(this->body,body);
    stpcpy(this->end,end);
}

Socket_Pack::Socket_Pack()
{
    memset(head,'\0',_HEAD_SIZE);
    memset(body,'\0',_BODY_SIZE);
    memset(end,'\0',_END_SIZE);
    this->code=0;
}

void Socket_Pack::setCode(int code)
{
    this->code=code;
}