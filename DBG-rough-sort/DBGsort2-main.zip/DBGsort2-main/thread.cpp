#include "thread.h"

void str_break(char* str, char* str1, char* str2)
{
	int num = 0;

	for (int i = 0; i < strlen(str); i++)
	{
		if (str[i] == ' ')
		{
			num = i;
			break;
		}
	}

	for (int i = 0; i < num; i++)
	{
		str1[i] = str[i];
	}

	for (int i = num + 1, j = 0; i < strlen(str); i++, j++)
	{
		str2[j] = str[i];
	}
}

unsigned preprocessing(const unsigned STORE, float* FVL1, float* FVL2, float* BVL1, float* BVL2, unsigned* ID)
{
	std::fstream Document;
	std::string DocumenteName = "src\\quickSort2.txt";
	Document.open(DocumenteName, std::ios::in);

	char temp1[30] = { 0 };
	char temp2[30] = { 0 };
	char temp3[30] = { 0 };

	char fv1[15] = { 0 };
	char fv2[15] = { 0 };
	char bv1[15] = { 0 };
	char bv2[15] = { 0 };
	
	unsigned num = 0;


	while (Document.getline(temp1, sizeof(char) * 30))
	{
		
		Document.getline(temp2, sizeof(char) * 30);
		Document.getline(temp3, sizeof(char) * 30);

		str_break(temp1, fv1, fv2);
		str_break(temp2, bv1, bv2);

		FVL1[num] = atof(fv1);
		FVL2[num] = atof(fv2);
		BVL1[num] = atof(bv1);
		BVL2[num] = atof(bv2);
		ID[num] = atof(temp3);

		num++;

		//if (num == _TIME_)break;

		//printf("%f\n%f\n%f\n%f\n%d\n\n", FVL1[num], FVL2[num], BVL1[num], BVL2[num], ID[num]);
	}
		
	Document.close();

	return num;
}

void search(float* fv1, float* fv2, float *bv1, float* bv2, unsigned* id, unsigned line, std::string* res)
{
	for (unsigned i = 0; i < line; i++)
	{
		res[i] += std::to_string(id[i]);
		res[i] += "-";

		for (unsigned j = 0; j < line; j++)
		{
			if (
				(abs(bv1[i] - fv1[j]) < 0.000002) &&
				(abs(bv2[i] - fv2[j]) < 0.000002) &&
				(i != j)
				)
			{
				res[i]+= std::to_string(id[j]);
				res[i] += "��";
			}
		}
		//res[i].pop_back();
		std::cout << i << " line finished\n";
	}
}

void search_thread(float bv1, float bv2, float* fv1, float* fv2,
					unsigned* id, unsigned line, std::string* res,unsigned i,
					float BL[],unsigned BID[])
{
	    BID[i] = id[i];
		res[i] += std::to_string(id[i]);
		res[i] += "-";

		for (unsigned j = 0; j < line; j++)
		{

			if (
				(abs(bv1 - fv1[j]) < 0.001000) &&
				(abs(bv2 - fv2[j]) < 0.001000) && 
				(i != j)
				)
			{
				res[i] += std::to_string(id[j]);
				res[i] += " ";
			}
		}
}

void makeDocument(std::string* res,unsigned line)
{
	std::fstream result;
	result.open("src\\SimilarityTable.txt", std::ios::out | std::ios::trunc);
	for (unsigned i = 0; i < line; i++)
	{
		result << res[i]<<std::endl;
	}

	result.close();
}


void sortArr(float* fv1, float* fv2, float* bv1, float* bv2, unsigned* ID,std::string res)
{

}


float Paritition1(unsigned ID[], unsigned low, unsigned high, float fvl1[], float fvl2[], float bvl1[], float bvl2[])
{
	unsigned pivot = ID[low];
	float p1 = fvl1[low];
	float p2 = fvl2[low];
	float p3 = bvl1[low];
	float p4 = bvl2[low];
	while (low < high) 
	{
		while (low < high && ID[high] >= pivot) 
		{
			--high;
		}

		ID[low] = ID[high];
		fvl1[low] = fvl1[high];
		fvl2[low] = fvl2[high];
		bvl1[low] = bvl1[high];
		bvl2[low] = bvl2[high];
		

		while (low < high && ID[low] <= pivot) 
		{
			++low;
		}
		ID[high] = ID[low];
		fvl1[high] = fvl1[low];
		fvl2[high] = fvl2[low];
		bvl1[high] = bvl1[low];
		bvl2[high] = bvl2[low];
	}

	ID[low] = pivot;
	fvl1[low] = p1;
	fvl2[low] = p2;
	bvl1[low] = p3;
	bvl2[low] = p4;

	return low;
}

void QuickSort(unsigned ID[], unsigned low, unsigned high,float fvl1[],float fvl2[], float bvl1[],float bvl2[],unsigned& i) //����ĸ����
{
	if (low < high) 
	{
		unsigned pivot = Paritition1(ID, low, high, fvl1, fvl2, bvl1, bvl2);
		if (pivot > 0)
		{
			QuickSort(ID, low, pivot - 1, fvl1, fvl2, bvl1, bvl2, i);
			QuickSort(ID, pivot + 1, high, fvl1, fvl2, bvl1, bvl2, i);
		}
		
	}
}

void Bplus(unsigned ID[], float fvl1[], float fvl2[], float bvl1[], float bvl2[],float BL[],float BID[],unsigned LINE)
{
	for (unsigned i = 0; i < LINE; i += 10000)
	{
		BL[i] = fvl1[i];
		BID[i] = ID[i];
	}
}


unsigned Paritition1str(std::string res[], unsigned BID[], unsigned low, unsigned high)
{
	unsigned pivot = BID[low];
	std::string str = res[low];
	while (low < high)
	{
		while (low < high && BID[high] >= pivot)
		{
			--high;
		}

		BID[low] = BID[high];
		res[low] = res[high];


		while (low < high && BID[low] <= pivot)
		{
			++low;
		}
		BID[high] = BID[low];
		res[high] = res[low];
	}

	BID[low] = pivot;
	res[low] = str;
	return low;
}

void str_sort(std::string res[],unsigned BID[],unsigned low,unsigned high)
{
	//std::cout << low << " " << high << std::endl;
	if (low < high)
	{
	    
		unsigned pivot = Paritition1str(res, BID, low,  high);
		if (pivot > 0) 
		{
			str_sort(res, BID, low, pivot - 1);
			str_sort(res, BID, pivot + 1, high);
		}
		
	}
}