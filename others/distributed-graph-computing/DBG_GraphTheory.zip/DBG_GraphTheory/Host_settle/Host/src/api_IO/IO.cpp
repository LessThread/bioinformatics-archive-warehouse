#include "../../include/api_IO/IO.h"



namespace DBGGT_WINDOWS_HOST 
{
	namespace IO 
	{
		int readFile(std::vector<Node*>& node_vector, std::map<std::string, unsigned>& bplus_maps, 
					const std::string match_file_path, const std::string bplus_file_path)
		{
			std::fstream fp;
			fp.open(match_file_path, std::ios::in);

			char* temp = nullptr;
			try 
			{
				temp = new char[_TEMP_BUF_SIZE_];
			}
			catch(const std::bad_alloc& e)
			{
				throw "Bad alloc in readFile";
			}
			memset(temp, '\0', sizeof(char) * _TEMP_BUF_SIZE_);

			while (fp.getline(temp, sizeof(char) * _TEMP_BUF_SIZE_))
			{
				std::string string_id;
				unsigned count = 0;

				//����ͷ��id
				for ( ;count < _TEMP_BUF_SIZE_; ++count)
				{
					if (temp[count]=='-')
					{
						count++;
						break;
					}
					else
					{
						string_id += temp[count];
					}
				}
				//...

				Node* NodeBody = DBGGT_WINDOWS_HOST::NODE_METHOD::FindORCreateNode(string_id, node_vector, bplus_maps);
				
				//����ͷ��id��β��id
				std::string linking_object = "";
				for (; count < _TEMP_BUF_SIZE_ && temp[count] != '\0'; count++)
				{
					if (temp[count] == ' ')
					{
						DBGGT_WINDOWS_HOST::NODE_METHOD::link(linking_object, NodeBody,bplus_maps,node_vector);
						linking_object = "";
					}
					else
					{
						linking_object += temp[count];
					}
					if (temp[count + 1] == '\0')
					{
						DBGGT_WINDOWS_HOST::NODE_METHOD::link(string_id, NodeBody, bplus_maps, node_vector);
						break;
					}
				}
				//...
			}

			return 0;
		}

		int outputResult()
		{
			return 0;
		}
	}
}