#include "../../include/api_buildpath/buildpath.h"
namespace DBGGT_LINUX_COLONY {
	namespace BUILD_PATH {
		int BFS(Node* ptr,
			std::vector<std::string*>* str,
			std::vector<std::pair<std::string, std::string>>* wait,
			BPlusTree* T,
			std::map < std::string, long long > bmaps,
			std::vector<Node*>& Nvector)
		{

		}
	}
}