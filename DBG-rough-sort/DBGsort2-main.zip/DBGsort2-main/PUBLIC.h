#pragma once
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <cstdlib>
#include <stdlib.h>
#include <thread>
#include <vector>
#include <mutex>
#include <chrono>
#include <stdexcept>
#include <csignal>
#include <ctime>
#include<condition_variable>

#define  BUF_SIZE 100
#define _TIME_ 10000


