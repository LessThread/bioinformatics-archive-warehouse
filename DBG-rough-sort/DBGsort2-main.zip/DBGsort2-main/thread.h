#pragma once
#pragma warning(disable : 4996)
#include "PUBLIC.h"


unsigned preprocessing(const unsigned STORE, float* FVL1, float* FVL2, float* BVL1, float* BVL2, unsigned* ID);
void search(float* fv1, float* fv2, float* bv1, float* bv2, unsigned* id, unsigned line, std::string* res);
void makeDocument(std::string* res, unsigned line);

void search_thread(float bv1, float bv2, float* fv1, float* fv2,
	unsigned* id, unsigned line, std::string* res, unsigned i,
	float BL[], unsigned BID[]);

void QuickSort(unsigned ID[], unsigned low, unsigned high, float fvl1[], float fvl2[], float bvl1[], float bvl2[],unsigned& i); //����ĸ����
void Bplus(unsigned ID[], float fvl1[], float fvl2[], float bvl1[], float bvl2[], float BL[], float BID[], unsigned LINE);
void str_sort(std::string res[], unsigned BID[], unsigned low, unsigned high);