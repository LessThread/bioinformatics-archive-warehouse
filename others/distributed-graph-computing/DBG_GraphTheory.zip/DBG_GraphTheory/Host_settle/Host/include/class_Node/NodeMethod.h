#pragma once
#include "./Node.h"
namespace DBGGT_WINDOWS_HOST
{
	namespace NODE_METHOD
	{
		Node* FindORCreateNode(std::string s_id, std::vector<Node*>& Nvector, std::map<std::string, unsigned>& maps);
		Node* link(std::string pointer, Node* bodys, std::map<std::string, unsigned>& maps, std::vector<Node*>& Nvector);

	}
}