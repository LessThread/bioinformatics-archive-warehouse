#include "./IO.h"

extern std::vector<std::string*>StringVector;
extern std::string MatchedString;

void inputFile(std::string filename)
{
    std::fstream fp;
    fp.open(filename,std::ios::in);
    if(!fp.is_open())
    {
        std::cout<<"File input error";
        exit(1);
    }
    
    char* buf = new char[200];
    while (fp.getline(buf,200))
    {
        fp.getline(buf,200);
        std::string* str = new std::string(buf);
        StringVector.push_back(str);
    }
    fp.close();
}

void outputFile(std::string filename_EM,std::string filename_Match)
{
    std::fstream fp_EM;
    std::fstream fp_Match;
    fp_EM.open(filename_EM,std::ios::out|std::ios::trunc);
    fp_Match.open(filename_Match,std::ios::out|std::ios::trunc);
    if(!fp_EM.is_open() || !fp_Match.is_open())
    {
        std::cout<<"File input error";
        exit(1);
    }

    long index = 0;
    fp_Match<<index<<"-";

    
    fp_EM<<index++<<"\n";
    fp_EM<<MatchedString<<"\n";
    fp_EM<<"0,"<<"\n";
    fp_EM<<"\n";
    fp_EM<<"0,\n";
    fp_EM<<"\n";
    fp_EM<<"---\n";

    

    for(auto iter : StringVector)
    {
        fp_EM<<"---\n";
        fp_Match<<index<<",";
        fp_EM<<index++<<"\n";
        fp_EM<<*iter<<"\n";
        fp_EM<<"0,"<<"\n";
        fp_EM<<"\n";
        fp_EM<<"0,\n";
        fp_EM<<"\n";
    }

    fp_EM.close();
}