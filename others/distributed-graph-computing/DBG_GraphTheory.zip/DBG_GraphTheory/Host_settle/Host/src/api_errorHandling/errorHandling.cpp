#include "../../include/api_errorHandling/errorHandling.h"
namespace DBGGT_WINDOWS_HOST
{
	namespace ERR
	{
		void generalError(const char* errMessage)
		{
			std::cout << "Error: " << errMessage << std::endl;
		}

		void unknownError()
		{
			std::cout << "Unknow Error Happended!\n";
		}

		void printWarning(const char* WatningMessage)
		{
			std::cout <<"Warning: "<< WatningMessage << std::endl;
		}
	}
}