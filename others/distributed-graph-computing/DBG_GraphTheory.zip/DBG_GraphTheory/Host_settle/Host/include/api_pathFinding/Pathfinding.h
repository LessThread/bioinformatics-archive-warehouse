#pragma once
#include<thread>
namespace DBGGT_WINDOWS_HOST
{
	namespace PATHFINDING
	{
		int pathFinding();
	}
}
