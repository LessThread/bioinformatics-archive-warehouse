#define once
#include "./SocketPack.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/socket.h>
#include <sys/unistd.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <iostream>
#include <errno.h>

#define _BUFF_SIZE 20480
#define _SERVER_IP "127.0.0.1"    // 指定服务端的IP，记得修改为你的服务端所在的ip
#define _SERVER_PORT 16595        // 指定服务端的port
#define _CONNCET_TEST_MESSAGE "Linux cluster is ready..."
#define _PER_WAIT_TIME 6000
#define _MAX_WAIT_TIME 100

int BUFF_SIZE;

char* send_buff;
char* recv_buff;
int sockfd;

int initSocket();//初始化套接字
int connectWindowsServer();//初始化连接
int getGraphInformation();//唤醒后请求子图分发
int askForBplus();//请求b+序列
int closeSocket();//关闭链接