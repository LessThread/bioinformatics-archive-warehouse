#pragma comment(lib,"ID-wash-2.lib")
#include<string>

__declspec(dllimport)void callIDWash(std::string BPlusFile = "G:\\Test\\id-test3\\EM_res.txt",std::string MatchFile = "G:\\Test\\id-test3\\result30_example0.txt",std::string outputMatch = "G:\\Test\\id-test3\\99file1.txt",std::string finalOutput = "G:\\Test\\id-test3\\99file2.txt");

int main()
{
    callIDWash();
}