#pragma once
#include<iostream>

namespace DBGGT_WINDOWS_HOST
{
	namespace ERR 
	{
		void generalError(const char* errMessage);
		void unknownError();
		void printWarning(const char* WatningMessage);
	}
}
