extern "C" _declspec(dllexport)void start(std::string readName, std::string matchName);
