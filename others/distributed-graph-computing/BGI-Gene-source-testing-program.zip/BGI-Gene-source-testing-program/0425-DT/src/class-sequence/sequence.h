#pragma once
#include "../settings.h"
#include <iostream>
#undef _MOD_NAME_
#define _MOD_NAME_ SEQUENCE

namespace _MOD_NAME_
{
    class class_sequence
    {
    private:
    public:
        std::string* seq;
        std::string* line1;
        std::string* line2;
        std::string* line3;
        std::string* line4;
        std::string* line5;
        std::string* line6;
        float first_value;
        float second_value;
        int id;

        class_sequence(std::string*,float,float,int);
        ~class_sequence();
    };
    
    
    
}