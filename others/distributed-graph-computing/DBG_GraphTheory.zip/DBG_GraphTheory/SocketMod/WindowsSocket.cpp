#include "./WindowsSocket.h"

namespace DBGGT_WINDOWS_HOST
{
    namespace NETWORK_MOD
    {
        int initSocket()
        {
            //初始化套接字，启动Windows socket2 环境
            WORD ver = MAKEWORD(2, 2);
            WSADATA dat;
            WSAStartup(ver, &dat);

            // 校验版本
            if (2 != HIBYTE(dat.wVersion) || 2 != LOBYTE(dat.wVersion))
            {
                // 版本不对
                WSACleanup();
                return 0;
            }

            //1 建立一个socket
            SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

            sockaddr_in sin = {};
            sin.sin_family = AF_INET;

            sin.sin_addr.S_un.S_addr = inet_addr(_SERVER_IP);
            //servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
            //注：此段的设定和服务器网卡IP有关，内网保持默认设置即可
            sin.sin_port = htons(_SERVER_PORT);

            //2 bind 绑定用于接受客户端链接的网络端口
            if (SOCKET_ERROR == bind(sock, (sockaddr*)&sin, sizeof(sin)))
            {
                cout << "绑定网络端口失败" << endl;
            }
            else {
                cout << "绑定网络端口成功" << endl;
            }
                //3. listen监听网络端口
            if (SOCKET_ERROR == listen(sock, 20))
            {
                cout << "监听网络端口失败" << endl;
            }
            else {
                cout << "监听网络端口成功" << endl;
            }

            //4 accept 等待客户端
            sockaddr_in clientAddr = {};
            int nAddrLen = sizeof(sockaddr_in);
            SOCKET cSock = INVALID_SOCKET;
            string msg = "主机接收到客户端请求";
            cSock = accept(sock, (sockaddr*)&clientAddr, &nAddrLen);

            if (INVALID_SOCKET == cSock)
            {
                cout << "错误，接受到无效客户端SOCKET..." << endl;
            }

            cout << "新客户端加入：" << inet_ntoa(clientAddr.sin_addr) << endl;
            
            //5 send 
            char recvBuf[10000] = {};
            int keep=0;
            while (true)
            {
                
                int nlen = recv(cSock, recvBuf, sizeof(infm)+2, 0);
                infm* in = (infm*)malloc(sizeof(infm));
                memcpy(in,recvBuf, sizeof(infm));
                std::cout<<in->num<<" "<<in->num2<<" "<<in->str;
                send(cSock, msg.c_str(), msg.length(), 0);
                if (nlen <= 0 )
                {
                    break;
                }
            }

            std::cout<<"服务端退出\n";
            closesocket(sock);
            WSACleanup();
        }
    }
}

