#define WIN32_LEAN_AND_MEAN

#include <iostream>
#include <thread>
#include <vector>
#include <WinSock2.h>
#include "./SocketPack.h"

#pragma comment(lib, "ws2_32.lib")
#pragma pack(1)

#define _BUFF_SIZE 20480
#define _SERVER_IP "127.0.0.1"    // 指定服务端本机网卡的IP（局域网应该是默认设置）
#define _SERVER_PORT 16595        // 指定服务端的port
#define _CONNCET_TEST_MESSAGE "Windows server is ready..."
#define _PER_WAIT_TIME 6000
#define _MAX_WAIT_TIME 100

/*
    架构说明：Windows主机先初始化，多线程同时执行集群链接、b+树读取，图生成和图分割
*/

namespace DBGGT_WINDOWS_HOST
{
    namespace NETWORK_MOD
    {
        std::vector<Socket_Pack*>socket_vector;
        
        int initSocket(); //初始化套接字，监听端口消息
        int prepareDistribution(); //图拆分完毕，准备分发
        int distributionSubgraph(); //给（指定）集群分发（指定）子图 （异步）
        int closeSocket(); //终止套接字，断开与子集群的链接
    }
}






