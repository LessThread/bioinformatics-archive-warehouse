//dll.h
#ifndef DLL_H_
#define DLL_H_
extern "C" _declspec(dllexport)void start(std::string readName, std::string matchName);
#endif
