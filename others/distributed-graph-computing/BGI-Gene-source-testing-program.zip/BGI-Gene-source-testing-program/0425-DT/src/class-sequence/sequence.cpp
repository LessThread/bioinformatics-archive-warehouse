#include "./sequence.h"

namespace _MOD_NAME_
{
    class_sequence::class_sequence(std::string* seq,float first_value,float second_value,int id)
    {
        this->seq = seq;
        this->first_value = first_value;
        this->second_value = second_value;
        this->id = id;
    }
    
    class_sequence::~class_sequence()
    {
        delete this->seq;
        delete this->line1;
        delete this->line2;
        delete this->line3;
        delete this->line4;
        delete this->line5;
        delete this->line6;
    }
    
}
