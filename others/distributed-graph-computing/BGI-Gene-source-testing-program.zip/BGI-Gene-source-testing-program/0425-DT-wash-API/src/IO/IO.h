#include "../../include/settings.h"
void inputFile(std::string filename);
void outputFile(std::string filename_EM,std::string filename_Match);