#include "IO.h"


extern std::vector<SEQUENCE::class_sequence*> seq_vector;
extern std::vector<int> res_vector;
extern std::vector<std::string> res_str_vector;
extern std::vector<SEQUENCE::class_sequence*> res_seq;

namespace _MOD_NAME_
{
    void toInput(std::string FileName)
    {

        std::fstream fp;
        fp.open(FileName,std::ios::in);
        if (!fp.is_open()) { puts("ERR in open"); }

        const int BUF_SIZE = 500;
        char* temp_buf = new char[BUF_SIZE];
        while (fp.getline(temp_buf, (sizeof(char))*BUF_SIZE))
        {
            //这里或者使用全局编号
            //std::cout<<temp_buf<<"\n";
            int id = std::stoi(std::string(temp_buf));

            //提取碱基序列
            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* sequence = new std::string(temp_buf);

            //提取首个顺序特征值和逆序特征值
            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* line1 = new std::string(temp_buf);
            char value_char1[100]={0};
            for(int j=0;j<BUF_SIZE;j++)
            {
                if(temp_buf[j] == ',')break;
                else{value_char1[j] = temp_buf[j];}
            }
            float first_value = std::stof(std::string(value_char1));

            //提取次个顺序特征值和逆序特征值
            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* line2 = new std::string(temp_buf);
            char value_char2[100]={0};
            for(int j=0;j<BUF_SIZE;j++)
            {
                if(temp_buf[j] == ',')break;
                else{value_char2[j] = temp_buf[j];}
            }
            float second_value = std::stof(std::string(value_char2));


            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* line3 = new std::string(temp_buf);

            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* line4 = new std::string(temp_buf);

            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* line5 = new std::string(temp_buf);

            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            std::string* line6 = new std::string(temp_buf);

            fp.getline(temp_buf, (sizeof(char))*BUF_SIZE);
            //std::cout<<*line2<<"\n";

            SEQUENCE::class_sequence* cla_seq = new SEQUENCE::class_sequence(sequence,first_value,second_value,id);
            cla_seq->line1 = line1;
            cla_seq->line2 = line2;
            cla_seq->line3 = line3;
            cla_seq->line4 = line4;
            cla_seq->line5 = line5;
            cla_seq->line6 = line6;
            seq_vector.push_back(cla_seq);

        }

        fp.close();
        
    }

    void toOutput(std::string FileName)
    {
        std::fstream fp;
        fp.open(FileName,std::ios::out|std::ios::trunc);
        if (!fp.is_open()) { puts("ERR in open"); }

        for(auto iter : res_seq)
        {
            // std::cout<<
            // iter->id<<"\n"<<
            // *(iter->seq)<<"\n"<<
            // *(iter->line1)<<"\n"<<
            // *(iter->line2)<<"\n"<<
            // *(iter->line3)<<"\n"<<
            // *(iter->line4)<<"\n"<<
            // *(iter->line5)<<"\n"<<
            // *(iter->line6)<<"\n"<<
            // "---\n";

            // getchar();
            
            fp<<
            iter->id<<"\n"<<
            *(iter->seq)<<"\n"<<
            *(iter->line1)<<"\n"<<
            *(iter->line2)<<"\n"<<
            *(iter->line3)<<"\n"<<
            *(iter->line4)<<"\n"<<
            *(iter->line5)<<"\n"<<
            *(iter->line6)<<"\n"<<
            "---\n";
        }
        
        fp.close();
    }
}