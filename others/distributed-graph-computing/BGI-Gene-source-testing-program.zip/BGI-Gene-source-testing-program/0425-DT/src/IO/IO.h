#pragma once
#include "../settings.h"
#include "../class-sequence/sequence.h"
#include <iostream>
#include <fstream>

#undef _MOD_NAME_
#define _MOD_NAME_ IO

namespace _MOD_NAME_
{
    void toInput(std::string FileName);
    void toOutput(std::string FileName);
}