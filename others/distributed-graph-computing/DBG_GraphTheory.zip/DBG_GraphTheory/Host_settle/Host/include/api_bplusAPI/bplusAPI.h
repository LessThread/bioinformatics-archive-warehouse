#pragma once
#include "../../lib/bplus_lib/bplus.h"
namespace DBGGT_WINDOWS_HOST

{
	namespace BPLUS_API
	{
		std::string find_seq(std::string i, BPlusTree* T, std::map < std::string, long long > bmaps);
		void call_init(std::string str, BPlusTree** BPlusT, std::map<std::string, long long>& bmaps);
	}
}