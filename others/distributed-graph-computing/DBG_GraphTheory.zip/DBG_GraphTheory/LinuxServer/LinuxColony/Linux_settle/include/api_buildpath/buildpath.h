#pragma once
#include "../class_Node/Node.h"
namespace DBGGT_LINUX_COLONY {
	namespace BUILD_PATH {
		int BFS();
	}
}