﻿#include "include/class_Node/Node.h"

namespace DBGGT_LINUX_COLONY {
	namespace MAIN {
		int buildPath()
		{

		}
	}
}

int main()
{
	std::vector<Node*>node_vector;//所有节点的容器
	std::map<std::string, long long>bplus_maps;//b+树映射图

	std::vector<Node*>head_node_vector;
	std::vector<Node*>end_node_vector;
	std::vector<Node*>bridge_node_vector;

	std::vector<std::string*>result_string;
}