#include "./LinuxSocket.h"

int connectWindowsServer();

int initSocket( const int $BUFF_SIZE = _BUFF_SIZE,
                const char SERVER_IP[] = _SERVER_IP,
                const int SERVER_PORT = _SERVER_PORT)
{
    //初始化函数为默认值
    BUFF_SIZE = $BUFF_SIZE;

    send_buff = (char*)malloc(BUFF_SIZE);
    recv_buff = (char*)malloc(BUFF_SIZE);
    memset(send_buff,'\0',BUFF_SIZE);
    memset(recv_buff,'\0',BUFF_SIZE);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(-1 == sockfd)
    {
        printf("Create socket error(%d): %s\n", errno, strerror(errno));
        return -1;
    }

    struct sockaddr_in servaddr;
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    inet_pton(AF_INET, SERVER_IP, &servaddr.sin_addr);
    servaddr.sin_port = htons(SERVER_PORT);

    if (-1 == connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)))
    {
        printf("Connect error(%d): %s\n", errno, strerror(errno));
        return -1;
    }

    printf("The socket initialized successfully\n");
}


void creatPack(int socket,char* message)
{
    Socket_Pack* pack = new Socket_Pack(message);
    memcpy(send_buff,pack,sizeof(Socket_Pack));
    delete pack;
}

Socket_Pack* creatPack(int socket,char* head,char* body,char* end)
{
    Socket_Pack* pack = new Socket_Pack(head,body,end);
}

Socket_Pack* parsePackage(char* recvBuff)
{
    Socket_Pack* pack = new Socket_Pack();
    memcpy(pack,recvBuff,sizeof(Socket_Pack));
    return pack;
}

void waitWoken()
{
    creatPack(sockfd,_CONNCET_TEST_MESSAGE);
    int wait_key=1;
    while (1)
    {
        sleep(_PER_WAIT_TIME);
        send(sockfd, send_buff,BUFF_SIZE, 0);
        recv(sockfd, recv_buff, BUFF_SIZE, 0);
        Socket_Pack* back_pack = parsePackage(recv_buff);
        bzero(send_buff, sizeof(send_buff));
        bzero(recv_buff, sizeof(recv_buff));

        if(back_pack->code==2)
        {
            break;
        }

        else if(wait_key==_MAX_WAIT_TIME)
        {
            //等待超时，置错
        }
    }

    return;
}

int closeSocket()
{
    
}

int connectWindowsServer()
{
    creatPack(sockfd,_CONNCET_TEST_MESSAGE);

    send(sockfd, send_buff,BUFF_SIZE, 0);
    printf("Send: %s\n",send_buff);
    
    recv(sockfd, recv_buff, BUFF_SIZE, 0);
    printf("Recv: %s\n", recv_buff);
    
    Socket_Pack* back_pack = parsePackage(recv_buff);
    
    bzero(send_buff, sizeof(send_buff));
    bzero(recv_buff, sizeof(recv_buff));

    if(back_pack->code==1)
    {
        waitWoken();
    }

    else
    {
        //连接失败，置错
        closeSocket();
        return -1;
    }
    

    //此时主机已完成任务

    // try{acceptInformation();}
    // catch(...){close(sockfd);}
   
    return 0;
}