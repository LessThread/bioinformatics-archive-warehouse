#include "./include/settings.h"
#include "./include/IO.h"
#include "./include/SequenceUnit.h"
//#include "./main.h"
namespace _PROJECT_NAME_
{
    std::vector<std::string*> content_char_list;
    std::vector<SEQUENCE_UNIT::SequenceUnit*> sequence_vector;

    int gobal_index = 0;
    int file_index = 0;
    int gobal_end = 0;
    int out_index = 0;
}


using namespace _PROJECT_NAME_;
int main(int argc,char** argv)
{
    //默认设置
    std::string in_file_name = _IN_FILE_NAME_;
    std::string out_file_name = _OUT_FILE_NAME_;


    std::cout<<"Read: "<<in_file_name<<"\nOutput: "<<out_file_name<<"\n";
    
        int index =0;
    while (gobal_end == 0)
    {
        puts("IO:I\n");
        //system("pause");
        IO::readFile(in_file_name);

        //单节点生成
        for(auto iter : content_char_list)
        {
            SEQUENCE_UNIT::SequenceUnit* temp = new SEQUENCE_UNIT::SequenceUnit(iter);
            //std::cout<<"---"<<index++<<"---\n";
            temp->generateCharacteristicValue(_POSITIVE_ORDER_);
            temp->generateCharacteristicValue(_REVERSE_ORDER_);

            sequence_vector.push_back(temp);


        }

        puts("IO:O\n");
        IO::writeFile(out_file_name+std::to_string(file_index++));

        printf("Finished.");

        puts("start delete");
        for(auto iter : sequence_vector)
        {
            delete iter;
        }

        puts("end delete");

        std::vector<std::string*>().swap(content_char_list);
        std::vector<SEQUENCE_UNIT::SequenceUnit*>().swap(sequence_vector);

        puts("end swap");
    }
    
}