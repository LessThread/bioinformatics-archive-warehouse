#include "../../include/class_Node/Node.h"
Node::Node(std::string inf)
{
	this->inf = inf;
	dfn=0;
	low=0;
	foot=0;
};

void Node::addNext(Node* pNext)
{
	this->next.push_back(pNext);
};

void Node::addFront(Node* pFront)
{
	this->next.push_back(pFront);
};