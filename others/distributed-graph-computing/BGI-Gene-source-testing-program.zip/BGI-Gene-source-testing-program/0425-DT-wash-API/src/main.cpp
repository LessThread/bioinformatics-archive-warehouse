#include "../include/settings.h"
#include "./IO/IO.h"

std::string MatchedString = "GTGCCTGTCTTCCTAAGATGTGTATAAGAGACAGGATACTTAGTGTTTGCCTAATCCTTCAACTGGGGAATACAAAGTGTAATGAAAATAAGTACAAAGT";
const std::string input_filename = "out-res.txt";
const std::string output_filename_EM = "EM.txt";
const std::string output_filename_Match = "Match.txt";
std::vector<std::string*>StringVector;


int main()
{
    inputFile(input_filename);
    outputFile(output_filename_EM,output_filename_Match);

}