#pragma once
#include"public.h"
#include "operate.h"
void readFile(std::vector<Node*>& Nvector, std::map<std::string, unsigned>& maps,std::string name);
void creatFile(std::vector<std::string*>str);


