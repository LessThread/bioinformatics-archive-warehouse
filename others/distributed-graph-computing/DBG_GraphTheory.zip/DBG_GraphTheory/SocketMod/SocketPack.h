#include<cstring>
#include<cstdlib>
#include<string>

#define _HEAD_SIZE 20
#define _BODY_SIZE 2048
#define _END_SIZE 20

/*
    规定code:简单为测试，常规为正式通信

    4  服务端携带图
    3  服务端携带序列
    2  服务端回应准备
    1  服务端回应未准备
    0  空包
    -1 客户端询问是否已准备
    -2 客户端携带序列
    -3 客户端携带图

*/

class Socket_Pack 
{
public:
    int code;
    char head[_HEAD_SIZE];
    char body[_BODY_SIZE];
    char end[_END_SIZE];
    Socket_Pack();
    Socket_Pack(char*);
    Socket_Pack(char*,char*,char*);
    void setCode(int);
};
