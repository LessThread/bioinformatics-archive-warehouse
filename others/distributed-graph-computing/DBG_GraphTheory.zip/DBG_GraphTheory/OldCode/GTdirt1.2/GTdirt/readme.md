## DBG图论处理程序

### 1.文件夹说明：

        本目录下有两个文件夹，第一个文件夹储存封装的Graph_Theory.dll(含相关头文件和lib)，附有测试程序和样本；

        第二个文件夹放置源代码，VS2022 v143 工具集编译，Release下有发布版本的EXE。

### 2.使用说明：

        需处理文件放置在同目录下的src文件夹下：match.txt , reads.txt , res.txt 分别为对接表，片段树，输出文件。

### 2.源码头文件说明

        除main.cpp外，所有源文件仅含同名头文件，头文件功能如下：

Node.h    

图节点的基本功能单位,

```
仅包含public.h
```

IO.h    

文件的读写与图构建

```
实现：IO.cpp
包含：operate.h public.h
```

operate.h    

图构建中的各种操作

```
实现：operate.cpp
包含：public.h
```

searcher.h    

图寻路计算的指针单位

```
实现：searcher.h
包含：public.h
```

navigate2.h    

图寻路计算的方法和处理

```
实现：navigate2.cpp
包含：public.h operate.h searcher.h StorageInterface.h
```

StorageInterface.h    

对B+树接口（bplus是修改的接口，关于B+树部分的文件功能请咨询相关成员）

```
实现：StorageInterface.cpp;
```

time.h

计时头文件

```
仅包含于mian.cpp
```

public.h

常用库集合

```
外部库：
<iostream>
<fstream>
<vector>
<map>
<stack>
<queue>
<set>
<string>
<thread>
```
