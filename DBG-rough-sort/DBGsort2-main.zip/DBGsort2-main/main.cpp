﻿#include "PUBLIC.h"
#include "thread.h"


int main()
{
	clock_t start = clock();

	const unsigned STORE = 2100000;
	const unsigned BUF_NUM = 10;
	const unsigned BIT_NUM = 30;


	/*char** FrontValueList = (char**)malloc(sizeof(char*) * STORE);
	char** BackValueList = (char**)malloc(sizeof(char*) * STORE);
	char** idList = (char**)malloc(sizeof(char*) * STORE);*/
	/*for (int i = 0; i < 10; i++)
	{
		FrontValueList[i] = (char*)malloc(sizeof(char) * BIT_NUM);
		BackValueList[i] = (char*)malloc(sizeof(char) * BIT_NUM);
		idList[i] = (char*)malloc(sizeof(char) * BIT_NUM);

		memset(FrontValueList[i], '\0', BIT_NUM);
		memset(BackValueList[i], '\0', BIT_NUM);
		memset(idList[i], '\0', BIT_NUM);
	}*/


	float* FVL1 = (float*)malloc(sizeof(float) * STORE / 3 * 2);
	float* FVL2 = (float*)malloc(sizeof(float) * STORE / 3 * 2);
	float* BVL1 = (float*)malloc(sizeof(float) * STORE / 3 * 2);
	float* BVL2 = (float*)malloc(sizeof(float) * STORE / 3 * 2);
	unsigned* ID = (unsigned*)malloc(sizeof(unsigned) * STORE / 3);

	const unsigned LINE = preprocessing(STORE, FVL1, FVL2, BVL1, BVL2, ID);


	unsigned line=0;
	std::vector<std::thread>threads;
	std::string* res = new std::string[LINE];

	unsigned i = 0;
	//clock_t Bstart = clock();
	//QuickSort(ID, 0, LINE - 1, FVL1, FVL2, BVL1, BVL2,i);
	//printf("%d\n", e); system("pause");
	float* BList = (float*)malloc(sizeof(float) * LINE / 10000);
	unsigned* BID = (unsigned*)malloc(sizeof(unsigned) * LINE);
	//system("pause");
	//clock_t Bend = clock();
	//for (int i = 0; i < 10000; i++)printf("%d:%f %f\n", ID[i], BVL1[i], FVL1[i]); system("Pause");
	//std::cout << "Btime:" << (double)(Bend - Bstart) / CLOCKS_PER_SEC << "秒" << std::endl;

	for(;line<LINE;line++)
	{
		if(line%3000==0)printf("start: %d thread\n", line);
		threads.push_back(std::thread(search_thread,BVL1[line],BVL2[line],FVL1,FVL2,ID,LINE,res,line,BList,BID));
	}
	
	for (auto iter = threads.begin(); iter != threads.end(); ++iter)
	{
		iter->join();//等待着所有线程都返回后开始处理
	}

	/*std::fstream Document;
	std::string DocumenteName = "src\\quickSort1.txt";
	Document.open(DocumenteName, std::ios::in);
	if (Document.fail())std::cout << "err";*/
	/*char** FrontValue = (char**)malloc(sizeof(char*) * BUF_NUM);
	char** BackValue = (char**)malloc(sizeof(char*) * BUF_NUM);
	char** id = (char**)malloc(sizeof(char*) * BUF_NUM);
	std::vector<std::thread>threads;

	unsigned num = 0;

	for (int i = 0; i < 10; i++)
	{
		FrontValue[i] = (char*)malloc(sizeof(char) * BIT_NUM);
		BackValue[i] = (char*)malloc(sizeof(char) * BIT_NUM);
		id[i] = (char*)malloc(sizeof(char) * BIT_NUM);

		memset(FrontValue[i], '\0', BIT_NUM);
		memset(BackValue[i], '\0', BIT_NUM);
		memset(id[i], '\0', BIT_NUM);
	}

	while (Document.getline(FrontValueList[num], sizeof(char) * BIT_NUM))
	{
		Document.getline(BackValueList[num], sizeof(char) * BIT_NUM);
		Document.getline(idList[num], sizeof(char) * BIT_NUM);
		std::cout<< FrontValue[num] <<" "<<BackValue[num]<<" "<<id[num] << std::endl;
		
		
		threads.push_back(std::thread());
		num++;
		system("pause");
	}
	*/
	//for (int i = 0; i < 10000; i++)printf("%d\n",BID[i]); system("Pause");
	str_sort(res, BID, 0, LINE - 1);
	makeDocument(res, LINE);



	free(FVL1);
	free(FVL2);
	free(BVL1);
	free(BVL2);
	free(ID);
	free(BID);
	free(BList);

	delete[](res);

	clock_t end = clock();
	std::cout<<"time:"<< (double)(end - start) / CLOCKS_PER_SEC << "秒" <<std:: endl;
	system("pause");
}
