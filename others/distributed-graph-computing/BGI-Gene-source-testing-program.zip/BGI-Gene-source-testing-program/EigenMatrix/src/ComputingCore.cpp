#include "../include/ComputingCore.H"

namespace _PROJECT_NAME_ 
{
    namespace _MOD_NAME_
    {
        void computer()
        {

        }
        
    }
}