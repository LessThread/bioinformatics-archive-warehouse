#include "../include/SequenceUnit.h"

namespace _PROJECT_NAME_ 
{
    namespace _MOD_NAME_
    {
        SequenceUnit::SequenceUnit()//空构造函数
        {
            
        }

        SequenceUnit::SequenceUnit(std::string* content)//常规构造函数
        {
            this->sequence = new std::string(content->substr(0,100));
            delete content;

        }
        
        SequenceUnit::~SequenceUnit()
        {
            delete sequence;
        }

        //此函数是用于计算两个碱基的变化率，返回伸缩变换后的int值
        int getCharacteristicPoint(char first,char second)
        {
            int first_value=0;
            int second_value=0;
            switch (first)
            {
            case 'A':
                first_value = _A_VALUE_;
                break;
            case 'T':
                first_value = _T_VALUE_;
                break;
            case 'C':
                first_value = _C_VALUE_;
                break;
            case 'G':
                first_value = _G_VALUE_;
                break;
            default:
                break;
            }

            switch (second)
            {
            case 'A':
                second_value = _A_VALUE_;
                break;
            case 'T':
                second_value = _T_VALUE_;
                break;
            case 'C':
                second_value = _C_VALUE_;
                break;
            case 'G':
                second_value = _G_VALUE_;
                break;
            default:
                break;
            }

            return (second_value - first_value);
        }

        
        void SequenceUnit::generateCharacteristicValue(int order)
        {
            std::string str = *(this->sequence);//先拷贝字符串
            std::vector<float>* temp_vector_15 = &(this->positive_value_container_15);
            if(order == _REVERSE_ORDER_ )//如果是反向指令则反转字符串
                {
                    std::reverse(str.begin(),str.end());
                    temp_vector_15 = &reverse_value_container_15;
                }
            int StrLen = str.length();


            for(int SeqLen = 15;SeqLen<=390;SeqLen+=15)
            {
                float TempValue = 0;
                if(SeqLen>StrLen)
                {
                    if(SeqLen-15 < StrLen)
                    {
                        for(int i=0;i<StrLen;i++)
                        {
                            switch (str[i])
                            {
                                case 'A': TempValue+=_A_CHARACTERISTIC_;break;
                                case 'G': TempValue+=_G_CHARACTERISTIC_;break;
                                case 'C': TempValue+=_C_CHARACTERISTIC_;break;
                                case 'T': TempValue+=_T_CHARACTERISTIC_;break;
                                case 'N': TempValue+=0;break;
                                default: throw("Err in text");break;
                            }
                        }
                        TempValue/=StrLen;
                    }
                }
                else
                {
                    int DivisorFactor = SeqLen;
                    for(int i = 0;;)
                    {
                        switch (str[i])
                        {
                            case 'A': TempValue+=_A_CHARACTERISTIC_;break;
                            case 'G': TempValue+=_G_CHARACTERISTIC_;break;
                            case 'C': TempValue+=_C_CHARACTERISTIC_;break;
                            case 'T': TempValue+=_T_CHARACTERISTIC_;break;
                            case 'N': TempValue+=0;break;
                            default: std::cout<<i<<str[i-2]<<str[i-1]<<str[i]<<str[i+1]<<str[i+2]<<std::endl;throw("Err in text");break;
                        }
                        if(i==SeqLen-1){break;}

                        if(i<StrLen-1){i++;}
                        else{DivisorFactor = i+1;break;}
                    }
                    TempValue /= DivisorFactor;
                }

                temp_vector_15->push_back(TempValue);
            }
            

            //.....................................

            str = *(this->sequence);//先拷贝字符串
            std::vector<float>* temp_vector_30 = &(this->positive_value_container_30);
            if(order == _REVERSE_ORDER_ )//如果是反向指令则反转字符串
                {
                    std::reverse(str.begin(),str.end());
                    temp_vector_30 = &reverse_value_container_30;
                }
            StrLen = str.length();


            for(int SeqLen = 30;SeqLen<=390;SeqLen+=30)
            {
                float TempValue = 0;
                if(SeqLen>StrLen)
                {
                    if(SeqLen-30 < StrLen)
                    {
                        for(int i=0;i<StrLen;i++)
                        {
                            switch (str[i])
                            {
                                case 'A': TempValue+=_A_CHARACTERISTIC_;break;
                                case 'G': TempValue+=_G_CHARACTERISTIC_;break;
                                case 'C': TempValue+=_C_CHARACTERISTIC_;break;
                                case 'T': TempValue+=_T_CHARACTERISTIC_;break;
                                case 'N': TempValue+=0;break;
                                default: throw("Err in text");break;
                            }
                        }
                        TempValue/=StrLen;
                    }
                }
                else
                {
                    int DivisorFactor = SeqLen;
                    for(int i = 0;;)
                    {
                        switch (str[i])
                        {
                            case 'A': TempValue+=_A_CHARACTERISTIC_;break;
                            case 'G': TempValue+=_G_CHARACTERISTIC_;break;
                            case 'C': TempValue+=_C_CHARACTERISTIC_;break;
                            case 'T': TempValue+=_T_CHARACTERISTIC_;break;
                            case 'N': TempValue+=0;break;
                            default: std::cout<<i<<str[i-2]<<str[i-1]<<str[i]<<str[i+1]<<str[i+2]<<std::endl;throw("Err in text");break;
                        }
                        if(i==SeqLen-1){break;}

                        if(i<StrLen-1){i++;}
                        else{DivisorFactor = i+1;break;}
                    }
                    TempValue /= DivisorFactor;
                }

                temp_vector_30->push_back(TempValue);
            }

            //..................................

            str = *(this->sequence);//先拷贝字符串
            std::vector<float>* temp_vector_45 = &(this->positive_value_container_45);
            if(order == _REVERSE_ORDER_ )//如果是反向指令则反转字符串
                {
                    std::reverse(str.begin(),str.end());
                    temp_vector_45 = &reverse_value_container_45;
                }
            StrLen = str.length();


            for(int SeqLen = 45;SeqLen<=390;SeqLen+=45)
            {
                float TempValue = 0;
                if(SeqLen>StrLen)
                {
                    if(SeqLen-45 < StrLen)
                    {
                        for(int i=0;i<StrLen;i++)
                        {
                            switch (str[i])
                            {
                                case 'A': TempValue+=_A_CHARACTERISTIC_;break;
                                case 'G': TempValue+=_G_CHARACTERISTIC_;break;
                                case 'C': TempValue+=_C_CHARACTERISTIC_;break;
                                case 'T': TempValue+=_T_CHARACTERISTIC_;break;
                                case 'N': TempValue+=0;break;
                                default: throw("Err in text");break;
                            }
                        }
                        TempValue/=StrLen;
                    }
                }
                else
                {
                    int DivisorFactor = SeqLen;
                    for(int i = 0;;)
                    {
                        switch (str[i])
                        {
                            case 'A': TempValue+=_A_CHARACTERISTIC_;break;
                            case 'G': TempValue+=_G_CHARACTERISTIC_;break;
                            case 'C': TempValue+=_C_CHARACTERISTIC_;break;
                            case 'T': TempValue+=_T_CHARACTERISTIC_;break;
                            case 'N': TempValue+=0;break;
                            default: std::cout<<i<<str[i-2]<<str[i-1]<<str[i]<<str[i+1]<<str[i+2]<<std::endl;throw("Err in text");break;
                        }
                        if(i==SeqLen-1){break;}

                        if(i<StrLen-1){i++;}
                        else{DivisorFactor = i+1;break;}
                    }
                    TempValue /= DivisorFactor;
                }

                temp_vector_45->push_back(TempValue);
            }
            
            
        }
    }
}