﻿//说明：此文件是主函数所在，负责初始化，数据传递，组织api
//最后更新：2022年10月

#include "include/api_IO/IO.h"
#include "include/api_errorHandling/errorHandling.h"
//#include "include/api_pathFinding/Pathfinding.h"

#define _DEFAULT_MATCH_FILE_NAME_ "./match.txt"
#define _DEFAULT_BPLUS_FILE_NAME_ "./bplus.txt"

namespace DBGGT_WINDOWS_HOST 
{
	namespace MAIN
	{
		//解析命令行
		int analyticParameter(int argc,char* argv[],std::string* match_file_path,std::string* bplus_file_path)//解析命令行参数，设置目录
		{

			if (argc == 1)
			{
				DBGGT_WINDOWS_HOST::ERR::printWarning("Default location will be used");
				return 0;
			}

			if (argc == 2) 
			{
				throw "Incorrect format";
				exit(1); 
			}

		    if (argc > 2)
			{
				if (strcmp(argv[1], "-m")==0)
				{
					*match_file_path = argv[2];
					if(argc>3)
					{
						DBGGT_WINDOWS_HOST::ERR::printWarning("Redundant parameters are ignored");
					}
				}

				else if(strcmp(argv[1], "-b") == 0)
				{
					*bplus_file_path = argv[2];
					if (argc > 3)
					{
						DBGGT_WINDOWS_HOST::ERR::printWarning("Redundant parameters are ignored");
					}
				}

				else if(strcmp(argv[1], "-mb") == 0)
				{
					*match_file_path = argv[2];
					if (argc == 3)
					{
						throw("Incorrect format\n");
					}
					*bplus_file_path = argv[3];
					if (argc > 4)
					{
						DBGGT_WINDOWS_HOST::ERR::printWarning("Redundant parameters are ignored");
					}
				}

				else
				{
					throw "Unknown command\n";
				}
				
			}

			return 0;

		}

		int initialize() //初始化b+树，读入对接表
		{
			//std::vector<std::thread>thread_vector;
			//DBGGT_WINDOWS_HOST::IO::readFile();
			//bplus::initialize()
			return 0;
		}

		int pretreatment() //分割子图，检索头桥尾节点
		{
			return 0;
		}

		int findPath() //传出到linux集群进行子图计算，然后接受计算结果
		{
			//DBGGT_WINDOWS_HOST::PATHFINDING::pathFinding();
			return 0;
		}

		int outputResult()//整合结果输出
		{
			//DBGGT_WINDOWS_HOST::IO::outputResult();
			return 0;
		}
}

}

int main(int argc, char* argv[])
{
	std::vector<Node*>node_vector;//所有节点的容器
	std::map<std::string, long long>bplus_maps;//b+树映射图
	
	std::vector<Node*>head_node_vector;
	std::vector<Node*>end_node_vector;
	std::vector<Node*>bridge_node_vector;

	std::vector<std::string*>result_string;

	std::string* match_file_path = new std::string(_DEFAULT_MATCH_FILE_NAME_);
	std::string* bplus_file_path = new std::string(_DEFAULT_BPLUS_FILE_NAME_);
	
	try
	{   //预处理
		DBGGT_WINDOWS_HOST::MAIN::analyticParameter(argc, argv, match_file_path,bplus_file_path);
		DBGGT_WINDOWS_HOST::MAIN::initialize();
		DBGGT_WINDOWS_HOST::MAIN::pretreatment();

		//寻路,生成字符串
		DBGGT_WINDOWS_HOST::MAIN::findPath();

		//整合输出
		DBGGT_WINDOWS_HOST::MAIN::outputResult();
	}
	catch (const char* errMessage)
	{
		DBGGT_WINDOWS_HOST::ERR::generalError(errMessage);
	}
	catch (...)
	{
		DBGGT_WINDOWS_HOST::ERR::unknownError();
	}

	return 0;
}

