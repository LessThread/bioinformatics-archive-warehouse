#include "../include/IO.h"

namespace _PROJECT_NAME_
{
    extern std::vector<std::string*> content_char_list;
    extern std::vector<SEQUENCE_UNIT::SequenceUnit*> sequence_vector;
    extern int gobal_index;
    extern int gobal_end;
    extern int out_index;

    namespace _MOD_NAME_
    {
        void readFile(std::string in_file_name)
        {
            unsigned count = 1;
            std::fstream fp;
            fp.open(in_file_name,std::ios::in);

            if(!fp.is_open())
            {
                printf("ERR: File open error!");
                exit(1);
            }

            char length_1[_LINE1_BUF_SIZE_];//@length = ...
            char content_2[_LINE2_BUF_SIZE_];//ACGGGT 只有这行是有效数据
            char blank_3[_LINE3_BUF_SIZE_];//+
            char value_4[_LINE4_BUF_SIZE_];//lllllllll

            int i=0;
            while(i<gobal_index)
            {
                fp.getline(length_1,(sizeof(char)*_LINE1_BUF_SIZE_));
                fp.getline(content_2,(sizeof(char)*_LINE2_BUF_SIZE_));
                fp.getline(blank_3,(sizeof(char)*_LINE3_BUF_SIZE_));
                fp.getline(value_4,(sizeof(char)*_LINE4_BUF_SIZE_));
                i++;
            }
            

            while(fp.getline(length_1,(sizeof(char)*_LINE1_BUF_SIZE_)))
            {
                fp.getline(content_2,(sizeof(char)*_LINE2_BUF_SIZE_));

                fp.getline(blank_3,(sizeof(char)*_LINE3_BUF_SIZE_));
                fp.getline(value_4,(sizeof(char)*_LINE4_BUF_SIZE_));

                std::string* _content = new std::string(content_2);
                content_char_list.push_back(_content);

                gobal_index++;
                if(gobal_index%5000000==0 && gobal_index>=5000000 ){fp.close();return;}

            }
            std::cout<<"gobal_end set 1:"<<gobal_index<<"\n";
            gobal_end = 1;
            fp.close();
        }

        void writeFile(std::string out_file_name)
        {
            std::fstream fp;
            fp.open(out_file_name,std::ios::out|std::ios::trunc);
            if(!fp.is_open())
            {
                printf("ERR: File open error!");
                exit(1);
            }

            for(auto iter : sequence_vector)
            {
                fp<<out_index<<"\n";
                //printf("%d\n",out_index);
                out_index++;
                fp<<*(iter->sequence)<<"\n";

                for(auto iter_pos : iter->positive_value_container_15)
                {
                    fp<<iter_pos<<",";
                }
                fp<<"\n";
                for(auto iter_rev : iter->reverse_value_container_15)
                {
                    fp<<iter_rev<<",";
                }
                fp<<"\n";


                for(auto iter_pos : iter->positive_value_container_30)
                {
                    fp<<iter_pos<<",";
                }
                fp<<"\n";
                for(auto iter_rev : iter->reverse_value_container_30)
                {
                    fp<<iter_rev<<",";
                }
                fp<<"\n";


                
                for(auto iter_pos : iter->positive_value_container_45)
                {
                    fp<<iter_pos<<",";
                }
                fp<<"\n";
                for(auto iter_rev : iter->reverse_value_container_45)
                {
                    fp<<iter_rev<<",";
                }
                fp<<"\n";

                fp<<"----\n";

            }

            puts("end loop");
            fp.close();
        }

    }
}