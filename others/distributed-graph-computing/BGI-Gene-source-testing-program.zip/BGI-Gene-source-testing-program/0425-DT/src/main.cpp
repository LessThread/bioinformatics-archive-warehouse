#include "settings.h"
#include "./IO/IO.h"
#include "./class-sequence/sequence.h"

const std::string SQE= "CACCTGTGTGTCCAATTTATATTCAACAGCGATTTGCTTCTAATTACGAATTCTCGAAGTATTTGTGCGCACACAAAACATAGGAACCGTTAATAAGTCG";
//const std::string tailSQE = SQE.substr(70,30);
//const std::string tailSQE = "AGTACAAAGT";
const float SQE_first_value = 6553.6;
const float SQE_second_value = 10922.7;
std::vector<SEQUENCE::class_sequence*> seq_vector;
std::vector<int> res_vector;
std::vector<std::string> res_str_vector;
std::vector<SEQUENCE::class_sequence*> res_seq;

int main()
{
    int total_num = 0;
    for(int i=0;i<38;i++)
    {
        std::cout<<"index:"<<i<<"\n";
        std::cout<<"total:"<<total_num<<"\n";

        std::string FileName = "../../res/EM_res.txt";
        FileName += std::to_string(i);
        IO::toInput(FileName);
        std::cout<<"vector_size:"<<seq_vector.size()<<"\n";
        
        for(auto iter : seq_vector)
        {
            total_num++;
            float res = SQE_second_value - iter->first_value;
            if( abs(res) < 0.1)
            {
                res_seq.push_back(iter);
            }
        }

        std::cout<<"Output\n";
        IO::toOutput("../../dt-res/out-res.txt");
        std::cout<<"Delet\n";


        for(auto iter : seq_vector)
        {
            delete iter;
        }
        std::vector<SEQUENCE::class_sequence*>().swap(res_seq);
        std::vector<SEQUENCE::class_sequence*>().swap(seq_vector);
    }

    
}