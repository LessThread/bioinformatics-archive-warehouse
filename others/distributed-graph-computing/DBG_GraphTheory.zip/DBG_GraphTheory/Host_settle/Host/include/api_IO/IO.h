#pragma once
#include<iostream>
#include<string>
#include<vector>
#include<map>
#include<fstream>
#include"../class_Node/Node.h"
#include "../../include/class_Node/NodeMethod.h"

#define _TEMP_BUF_SIZE_ 2000

namespace DBGGT_WINDOWS_HOST
{
	namespace IO 
	{
		int readFile(std::vector<Node*>& Nvector, std::map<std::string, unsigned>& maps, std::string name);
		int outputResult();
	}
}
